import React from 'react'
import Background from "../Image/discover.PNG"
import SplitScreen from '../Files/SplitScreen';
import Productpage from './ProductPage';
const Discover = () => {
  return (
    <div>
      <>
      <SplitScreen/>
      </>
    </div>
  )
}

export default Discover
